﻿#include <iostream>
#include <chrono>
#include <gperftools/tcmalloc.h>
#include "pool_obj.h"

#ifdef _DEBUG
#pragma comment(lib, "libtcmalloc_minimal-debug")
#else
#pragma comment(lib, "libtcmalloc_minimal")
#endif

class Test_1
{
public:
	Test_1(void)
	{
	}

	int a;
};

class Test_2 : public cPoolObj
{
public:
	Test_2(void)
	{
	}

	int a;
};

int main(void)
{
	std::cout << "시작" << std::endl;

	std::chrono::system_clock::time_point StartTime;
	std::chrono::system_clock::time_point EndTime;
	std::chrono::duration<double> DefaultSec;
	std::chrono::nanoseconds nano;
	std::chrono::microseconds micro;
	std::chrono::milliseconds mill;
	std::chrono::seconds sec;
	std::chrono::minutes min;
	std::chrono::hours hour;

	StartTime = std::chrono::system_clock::now();

	for (int i = 0; i < 1000000000; ++i)
	{
		Test_1* a = new Test_1();
		delete a;
	}

	EndTime = std::chrono::system_clock::now();
	DefaultSec = EndTime - StartTime;

	nano = EndTime - StartTime;
	micro = std::chrono::duration_cast<std::chrono::microseconds>(EndTime - StartTime);
	mill = std::chrono::duration_cast<std::chrono::milliseconds>(EndTime - StartTime);
	sec = std::chrono::duration_cast<std::chrono::seconds>(EndTime - StartTime);
	min = std::chrono::duration_cast<std::chrono::minutes>(EndTime - StartTime);
	hour = std::chrono::duration_cast<std::chrono::hours>(EndTime - StartTime);

	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << DefaultSec.count() << " default" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << nano.count() << " nanoseconds" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << micro.count() << " microseconds" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << mill.count() << " milliseconds" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << sec.count() << " seconds" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << min.count() << " minutes" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << hour.count() << " hour" << std::endl;

	std::cout << "==================================================" << std::endl;

	StartTime = std::chrono::system_clock::now();

	for (int i = 0; i < 1000000000; ++i)
	{
		Test_2* a = new Test_2();
		delete a;
	}

	EndTime = std::chrono::system_clock::now();
	DefaultSec = EndTime - StartTime;

	nano = EndTime - StartTime;
	micro = std::chrono::duration_cast<std::chrono::microseconds>(EndTime - StartTime);
	mill = std::chrono::duration_cast<std::chrono::milliseconds>(EndTime - StartTime);
	sec = std::chrono::duration_cast<std::chrono::seconds>(EndTime - StartTime);
	min = std::chrono::duration_cast<std::chrono::minutes>(EndTime - StartTime);
	hour = std::chrono::duration_cast<std::chrono::hours>(EndTime - StartTime);

	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << DefaultSec.count() << " default" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << nano.count() << " nanoseconds" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << micro.count() << " microseconds" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << mill.count() << " milliseconds" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << sec.count() << " seconds" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << min.count() << " minutes" << std::endl;
	std::cout << "Test() 함수를 수행하는 걸린 시간 : " << hour.count() << " hour" << std::endl;

	return 0;
}