#ifndef __C_POOLOBJ_H__
#define __C_POOLOBJ_H__

class cPoolObj
{
public:
	cPoolObj(void) {}
	virtual ~cPoolObj(void) {}

	void* operator new(size_t size)
	{
		return tc_new(size);
	}

	void* operator new[](size_t size)
	{
		return tc_new(size);
	}

	void operator delete(void* ptr)
	{
		tc_delete(ptr);
	}

	void operator delete[](void* ptr)
	{
		tc_delete(ptr);
	}
};

#endif
